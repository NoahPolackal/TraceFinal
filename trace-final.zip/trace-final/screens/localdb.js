const db = {
    1: {data:["1) Wacom Cintiq ","22"],image1:"https://cdn.mos.cms.futurecdn.net/kfBjPFEzVCRbKcHhvwg3Ld-970-80.jpg.webp"},
    2: {data:["2) iPad Pro","12.9-inch"],image1:"https://cdn.mos.cms.futurecdn.net/Jr3qgijwGqy3CqPc9UJ66W-970-80.jpg.webp"},
    3: {data:["3) XP-Pen Artist"," 15.6"],image1:"https://cdn.mos.cms.futurecdn.net/HdLktG28ydUNUqBpopVGr3-970-80.jpg.webp"},
    4: {data:["4) iPad Pro ","11-inch"],image1:"https://cdn.mos.cms.futurecdn.net/HJAVui2RF47tcRLvurodvG-970-80.jpg.webp"},
    5: {data:["5) Huion Kamvas ","Pro 24"],image1:"https://cdn.mos.cms.futurecdn.net/89pD5pxGYiwFnuREfcjGRA-970-80.jpg.webp"},
    6: {data:["6)  XP-PEN Innovator ","16"],image1:"https://cdn.mos.cms.futurecdn.net/dVMKE9mvMaqdYaysqvJgTX-970-80.jpg.webp"},

}
export default db;